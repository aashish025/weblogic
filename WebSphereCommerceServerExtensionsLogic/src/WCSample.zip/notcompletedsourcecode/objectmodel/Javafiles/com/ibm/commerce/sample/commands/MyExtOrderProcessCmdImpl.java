package com.ibm.commerce.sample.commands;
//*-------------------------------------------------------------------
//* Licensed Materials - Property of IBM
//*
//* WebSphere Commerce
//*
//* (c) Copyright International Business Machines Corporation. 2001, 2003, 2005
//*     All rights reserved.
//*
//* US Government Users Restricted Rights - Use, duplication or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
//*
//*-------------------------------------------------------------------
//* The sample contained herein is provided to you "AS IS".
//*
//* It is furnished by IBM as a simple example and has not been  
//* thoroughly tested under all conditions.  IBM, therefore, cannot guarantee its 
//* reliability, serviceability or functionality.  
//*
//* This sample may include the names of individuals, companies, brands 
//* and products in order to illustrate concepts as completely as 
//* possible.  All of these names
//* are fictitious and any similarity to the names and addresses used by 
//* actual persons or business enterprises is entirely coincidental.
//*---------------------------------------------------------------------


import com.ibm.commerce.exception.*;
import com.ibm.commerce.datatype.TypedProperty;
import com.ibm.commerce.extension.objects.OrderGiftAccessBean;
import com.ibm.commerce.order.commands.ExtOrderProcessCmdImpl;
import com.ibm.commerce.ras.ECMessage;

// This task command will be called at the end of the Order Process logic
// Extend the original implementation to include our own logic
// In our new implementation, we need to create an entry in the XORDGIFT 
// table.  This is done my creating a new OrderGift EJB and setting the proper
// values
public class MyExtOrderProcessCmdImpl
	extends ExtOrderProcessCmdImpl {
		
	public void performExecute() throws ECException {
		
		// call default code
		super.performExecute();
		
		// extract the request parameter that we need
		TypedProperty requestProperties = commandContext.getRequestProperties();
		String receipt   = requestProperties.getString("receiptName", null);
		String sender    = requestProperties.getString("senderName", null);
		String msgField1 = requestProperties.getString("msgField1", null);
		String msgField2 = requestProperties.getString("msgField2", null);

		try {
			// get the orderId for the order we're working on
			String orderId = getOrder().getOrderId();

			// create a new OrderGiftAccessBean to hold the data we've extracted
			OrderGiftAccessBean orderGiftAccessBean = 
					new OrderGiftAccessBean(new Long(orderId), receipt, sender, msgField1, msgField2);
		} catch (javax.naming.NamingException e) {
				throw new ECSystemException(ECMessage._ERR_NAMING_EXCEPTION, this.getClass().getName(), "performExecute");
		} catch (javax.ejb.FinderException e) {
				throw new ECSystemException(ECMessage._ERR_FINDER_EXCEPTION, this.getClass().getName(), "performExecute");
		} catch (javax.ejb.CreateException e) {
				throw new ECSystemException(ECMessage._ERR_CREATE_EXCEPTION, this.getClass().getName(), "performExecute");
		} catch (java.rmi.RemoteException e) {
				throw new ECSystemException(ECMessage._ERR_REMOTE_EXCEPTION, this.getClass().getName(), "performExecute");
		}
		
	}
}

package com.ibm.commerce.sample.databeans;

//*
//*-------------------------------------------------------------------
//* Licensed Materials - Property of IBM
//*
//* WebSphere Commerce
//*
//* (c) Copyright International Business Machines Corporation. 2001, 2005
//*     All rights reserved.
//*
//* US Government Users Restricted Rights - Use, duplication or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
//*
//*-------------------------------------------------------------------
//* The sample contained herein is provided to you "AS IS".
//*
//* It is furnished by IBM as a simple example and has not been  
//* thoroughly tested under all conditions.  IBM, therefore, cannot guarantee its 
//* reliability, serviceability or functionality.  
//*
//* This sample may include the names of individuals, companies, brands 
//* and products in order to illustrate concepts as completely as 
//* possible.  All of these names
//* are fictitious and any similarity to the names and addresses used by 
//* actual persons or business enterprises is entirely coincidental.
//*---------------------------------------------------------------------
import com.ibm.commerce.exception.*;
import com.ibm.commerce.ras.*;
import com.ibm.commerce.beans.SmartDataBean;
import com.ibm.commerce.command.CommandContext;
import com.ibm.commerce.datatype.TypedProperty;
import com.ibm.commerce.extension.objects.OrderGiftAccessBean;

/*
* This bean is used by the WebSphere Commerce programming tutorials. For information about this bean, see
* your WebSphere Commerce information center. 
*/
public class OrderGiftDataBean
	extends OrderGiftAccessBean implements SmartDataBean {

	private CommandContext commandContext = null;
	private TypedProperty requestProperties = null;
	private Long orderId = null;

	/**
	 * Returns the commandContext.
	 * @return CommandContext
	 */
	public CommandContext getCommandContext() {
		return commandContext;
	}

	/**
	 * Returns the requestProperties.
	 * @return TypedProperty
	 */
	public TypedProperty getRequestProperties() {
		return requestProperties;
	}

	/**
	 * Returns the orderId. Use this method when you need to use the value of the order ID. 
	 * @return orderId The unique identifier of the order that contains the gift message.
	 */
	public Long getOrderId() {
		return orderId;
	}

	/**
	 * Sets the commandContext.
	 * @param commandContext The commandContext to set
	 */
	public void setCommandContext(CommandContext commandContext) {
		this.commandContext = commandContext;
	}

	/**
	 * Sets the requestProperties.
	 * @param requestProperties The requestProperties to set
	 */
	public void setRequestProperties(TypedProperty requestProperties) {
		this.requestProperties = requestProperties;
	}
	
	/**
	 * Sets the orderId. Use this method when you need to set the order ID.
	 * @param orderID The unique identifier for the order that includes the gift message.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public void populate() throws ECException {

		// if the orderId has not already been set then obtain the orderID from the
		// request properties.  Throw an exception if there is no orderID.
		if (getOrderId() == null) {
			try {
				setOrderId(new Long(getRequestProperties().getString("orderId")));
			} catch (ParameterNotFoundException e) {
				throw new ECApplicationException(ECMessage._ERR_MISSING_PARAMETER,
					"OrderGiftDataBean", "populate",
					ECMessageHelper.generateMsgParms("orderId"));
			}
		}

		try {
			// load the data from the access bean
			setInitKey_ordersId(getOrderId());
			refreshCopyHelper();
		} catch (javax.naming.NamingException e) {
				throw new ECSystemException(ECMessage._ERR_NAMING_EXCEPTION, "OrderGiftDataBean", "populate");
		} catch (javax.ejb.FinderException e) {
				throw new ECSystemException(ECMessage._ERR_FINDER_EXCEPTION, "OrderGiftDataBean", "populate");
		} catch (javax.ejb.CreateException e) {
				throw new ECSystemException(ECMessage._ERR_CREATE_EXCEPTION, "OrderGiftDataBean", "populate");
		} catch (java.rmi.RemoteException e) {
				throw new ECSystemException(ECMessage._ERR_NAMING_EXCEPTION, "OrderGiftDataBean", "populate");
		}
	}
	
	public OrderGiftDataBean() {}
	
	// Create a new constructor for passing access bean into databean, so that the JSP page can use the access bean
	public OrderGiftDataBean(OrderGiftAccessBean ab) throws com.ibm.commerce.exception.ECException {
	try {
		super.setEJBRef(ab.getEJBRef());
	}  catch (javax.ejb.FinderException e) {
 			 	throw new ECSystemException(ECMessage._ERR_CREATE_EXCEPTION,
			 	"OrderGiftDataBean", "OrderGiftDataBean(ab)");
 	} catch (javax.naming.NamingException e) {
	 	throw new ECSystemException(ECMessage._ERR_NAMING_EXCEPTION, "OrderGiftDataBean", "OrderGiftDataBean(ab)");
 	} catch (java.rmi.RemoteException e) {
	 	throw new ECSystemException(ECMessage._ERR_REMOTE_EXCEPTION, "OrderGiftDataBean", "OrderGiftDataBean(ab)");
 	} catch (javax.ejb.CreateException e) {
	 	throw new ECSystemException(ECMessage._ERR_CREATE_EXCEPTION,  "OrderGiftDataBean", "OrderGiftDataBean(ab)");
 	}
}

}
